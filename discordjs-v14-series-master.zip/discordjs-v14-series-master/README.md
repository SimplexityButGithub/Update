[Discord.js V14 Series](https://djs14.underctrl.io/)
