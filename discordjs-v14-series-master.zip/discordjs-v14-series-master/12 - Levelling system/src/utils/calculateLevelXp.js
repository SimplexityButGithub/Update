module.exports = (level) => 100 * level || 1;
